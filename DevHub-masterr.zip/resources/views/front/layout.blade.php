<!DOCTYPE html>
{{-- [if IE 8 ]><html class="no-js oldie ie8" lang="en"> <![endif] --}}
{{-- [if IE 9 ]><html class="no-js oldie ie9" lang="en"> <![endif] --}}
{{-- [if (gte IE 9)|!(IE)]><! --}}
<html lang="{{ app()->getLocale() }}">
{{-- <![endif] --}}
<head>
	{{-- basic page needs --}}
	<meta charset="utf-8">
	<title>@yield('title', 'DevHub') | DevHub</title>
	<meta name="description" content="{{ isset($post) && $post->meta_description ? $post->meta_description : __('description') }}">
	<meta name="author" content="@lang(lcfirst ('Author'))">
	@if(isset($post) && $post->meta_keywords)
		<meta name="keywords" content="{{ $post->meta_keywords }}">
	@endif
    <meta name="csrf-token" content="{{ csrf_token() }}">
	@yield('meta')
	{{-- mobile specific metas --}}
	<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">

	{{-- CSS --}}
	{{-- <link rel="stylesheet" href="{{ asset('css/css.css') }}"> --}}
	<link href="https://fonts.googleapis.com/css?family=Roboto" rel="stylesheet">
	{{-- <link href="{{ asset('css/a11y-light.css') }}" rel="stylesheet"> --}}
	<link rel="stylesheet" href="{{ asset('css/vs.css') }}">
	<link rel="stylesheet" href="{{ asset('css/quill.snow.css') }}" rel="stylesheet">
	<link rel="stylesheet" href="{{ asset('css/quill.mention.min.css') }}">
	<link rel="stylesheet" href="{{ asset('css/normalize.css') }}">
	<link rel="stylesheet" href="{{ asset('css/vue-multiselect.min.css') }}">
	<link rel="stylesheet" href="{{ asset('css/font-awesome.min.css') }}">
	<link rel="stylesheet" href="{{ asset('plugins/semantic-ui/card.min.css') }}">
	{{-- iziToast --}}
	<link rel="stylesheet" href="{{ asset('plugins/iziToast/dist/css/iziToast.min.css') }}">
	{{-- endiziToast --}}
	<link rel="stylesheet" href="{{ asset('css/buttons.css') }}">
	<link rel="stylesheet" href="{{ asset('css/app.css') }}">
	@yield('css')

	{{-- favicon --}}
	<link rel="apple-touch-icon" sizes="180x180" href="{{ asset('favicon/apple-touch-icon.png') }}">
	<link rel="icon" type="image/png" sizes="32x32" href="{{ asset('favicon/favicon-32x32.png') }}">
	<link rel="icon" type="image/png" sizes="16x16" href="{{ asset('favicon/favicon-16x16.png') }}">
	<link rel="manifest" href="{{ asset('favicon//site.webmanifest') }}">
	<link rel="mask-icon" href="{{ asset('favicon/safari-pinned-tab.svg') }}" color="#5bbad5">
	<meta name="msapplication-TileColor" content="#da532c">
	<meta name="theme-color" content="#ffffff">

</head>

<body>
	{{-- Header --}}
	@include('include.header')

	@yield('main')

	{{-- Footer --}}
	@include('include.footer')

	{{-- Java Script --}}
	<script src="{{ asset('js/highlight.min.js') }}"></script>
	<script src="{{ asset('plugins/iziToast/dist/js/iziToast.min.js') }}"></script>
	<script src="{{ asset('js/app.js') }}"></script>
	@yield('scripts')
	<script>
		// var AuthUser = "{{{ (Auth::user()) ? Auth::user() : null }}}";
		// if (AuthUser){
		// 	iziToast.show({ 
		// 	    image: '{{--  Auth::user()->getMedia('avatars')->first()->getUrl('small') --}}',
		// 	    title: '{{-- Auth::user()->name --}}',
		// 	    message: 'Welcome!',
		// 	    progressBar: true,
		// 	    // timeout: 0,
		// 	    close:false,
		// 	    position: 'bottomCenter',
		// 	});
		// }
	    function Lang() {
	      document.getElementById("myDropdown").classList.toggle("show");
	    }

	    // Close the dropdown menu if the user clicks outside of it
	    window.onclick = function(event) {
	      if (!event.target.matches('.dropbtn')) {
	        var dropdowns = document.getElementsByClassName("dropdown-content");
	        var i;
	        for (i = 0; i < dropdowns.length; i++) {
	          var openDropdown = dropdowns[i];
	          if (openDropdown.classList.contains('show')) {
	            openDropdown.classList.remove('show');
	          }
	        }
	      }
	    }
	</script>

</body>
</html>
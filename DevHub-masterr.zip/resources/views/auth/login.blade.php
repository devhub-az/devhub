@extends('front.login-layout')

@section('title')Login səhifəsi @stop

@section('main')
<div class="container">
    <nav class="default-nav -colorless -session -borderless" data-js-nav-shift="session">
    <div class="right">
        <p>
            Hələ qeydiyyatdan keçməmisən?
            <span>
                <a class="btn btn_navbar_registration btn-reg" href="{{ route('register') }}">Qeydiyyatdan Keç</a>
            </span>
        </p>
    </div>
    </nav>
    <div class="PageColumns">
        <div class="PageColumn PageColumn__left">
            <div class="Art">
                
            </div>
        </div>
        <div class="PageColumn PageColumn__right">
            <div class="ColumnContainer mode-auth">
                <a href="{{ route('home') }}" class="logo_login">DevHub</a>
                <p class="desc">Xoş gəldiniz! Xahiş edirik məlumatlarınızı daxil edin və ya hesabınıza sosial şəbəkə hesabı ilə daxil olun.</p>
                <form method="POST" action="{{ route('login') }}">
                    @csrf
                    <fieldset class="AnimatedForm__field m-required login hideable m-valid">
                        <input id="email" type="email" class="AnimatedForm__textInput {{ $errors->has('email') ? ' is-invalid' : '' }}" data-empty="false" name="email" value="{{ old('email') }}" required autocomplete="email" autofocus>
                        <label class="AnimatedForm__textInputLabel" for="loginUsername">{{ __('validation.attributes.email') }}</label>
                        <div class="AnimatedForm__errorMessage"></div>
                    </fieldset>
                    <fieldset class="AnimatedForm__field m-required password hideable">
                        <input id="password" type="password" class="AnimatedForm__textInput {{ $errors->has('password') ? ' is-invalid' : '' }}" name="password" data-empty="false" required autocomplete="current-password">
                        <label class="AnimatedForm__textInputLabel" for="loginPassword">{{ __('validation.attributes.password') }}</label>
                        <div class="AnimatedForm__errorMessage"></div>
                    </fieldset>
                    <div class="form-group row mb-0">
                        <div class="col-md-8 offset-md-4">
                            <button type="submit" class="btn btn-primary">
                                Daxil ol
                            </button>

                            @if (Route::has('password.request'))
                                <a class="btn btn-link" href="{{ route('password.request') }}">
                                    Şifrəni unutmusan?
                                </a>
                            @endif
                        </div>
                    </div>
                </form>
                <footer>
                    Photo by Ilya Pavlov on Unsplash
                </footer>
            </div>
        </div>
    </div>
</div>
@endsection

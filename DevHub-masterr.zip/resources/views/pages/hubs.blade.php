@extends('front.layout')

@section('title')Hablar @stop

@section('css')
<link rel="stylesheet" href="{{ asset('css/pagination.css') }}">
@stop

@section('main')
<div class="layout_body">
	<div class="content_left" id="app">
		<div class="post-content__item">
			<hubs-list></hubs-list>
		</div>
	</div>
</div>
@endsection

@section('scripts')
@endsection
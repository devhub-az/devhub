@extends('front.layout')

@section('title'){{ ucfirst($user['username']) }} @stop

@section('meta')

@stop

@section('main')
<div class="profile_header">
	<div class="profile_cover">
		<div class="profile_user-info">
			<div class="profile_user-name">
				<h1>{{ ucfirst($user['name']) }} {{ '@' . $user['username'] }}</h1>
			</div>
			<div class="profile_user-about">
				<h3>{{ $user['about'] }}</h3>
				<h3 class="profile_user-city">Baku</h3>
			</div>
		</div>
	</div>
	<div class="profile_buttons">
		@if (Auth::check())
			@if (!$isFollowing)
				<a href="{{ route('user.follow', $user->id) }}" onclick="event.preventDefault(); document.getElementById('follow').submit();" class="btn btn-primary profile_user-connect">Abunə olun <span class="folowers">{{ \Numeric::number_format_short(count($user['followers'])) }}</span></a>
			@else
				<a href="{{ route('user.follow', $user->id) }}" onclick="event.preventDefault(); document.getElementById('unfollow').submit();" class="btn btn-primary profile_user-connect">Abunəsiz</a>
			@endif
		@else
			<a href="{{ route('user.follow', $user->id) }}" onclick="event.preventDefault(); document.getElementById('follow').submit();" class="btn btn-primary profile_user-connect">Abunə olun <span class="folowers">{{ \Numeric::number_format_short(count($user['followers'])) }}</span></a>
		@endif
		<a href="{{ route('create_post') }}" class="btn profile_user-message">Yazmağ</a>
		<div class="profile_content">
		</div>
	</div>
	<form id="follow" action="{{ route('user.follow', $user->id) }}" method="POST">
		{{ csrf_field() }}
	</form>
	<form id="unfollow" action="{{ route('user.unfollow', $user->id) }}" method="POST">
		{{ csrf_field() }}
	</form>
	{{-- <img src="{{ asset($user->getMedia('avatars')->first()->getUrl('big') ?? '') }}" alt="user avatar" class="profile_user-avatar"> --}}
</div>
@endsection

@section('scripts')
@endsection
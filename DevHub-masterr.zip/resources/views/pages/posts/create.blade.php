@extends('front.layout')

@section('title')Paylaşma yazmag @stop

@section('main')
<div class="layout_body">
  <div class="post_left">
    <div class="page-header page-header_110">
        <h1 class="page-header__title">Paylaşma yazmag</h1>
    </div>
    @if($errors->any())
        <div id="error" style="display: none"></div>
    @endif
    {!! Form::open(['id' => 'form', 'url' => 'posts', 'method' => 'POST']) !!}
    @csrf
    <p>
        {!! Form::label('title', 'Başlıq:') !!}
        
        {!! Form::text('title', null, ['class' => 'post__title', 'id' => 'title', 'placeholder' => 'Nəşrin nə olacağını başa düşmək üçün başlıq məna ilə doldurulmalıdır.', 'autocomplete' => 'off']) !!}
        <div class="description">
            @if($errors->has('title'))
                <p style="color: red"> {{ $errors->first('title') }}</p>
            @endif
        </div>
    </p>

    <p>
        {!! Form::label('text', 'Mətn:') !!}
        <div class="description">
            @if($errors->has('body'))
                <p style="color: red"> {{ $errors->first('body') }}</p>
            @endif
        </div>
        <div id="editor-container">
            {!! old('body') !!}
        </div>
    </p>

    <p>
        <tags></tags>
    </p>

    <p>
        {!! Form::submit('Paylaşımı əlavə etmək', ['id' => 'submit', 'class' => 'btn btn-primary']) !!}
    </p>

    {!! Form::close() !!}
  </div>
    <div class="content_right">
        <div class="default-block default-block_sidebar">
          <div class="default-block__header">
            <h3 class="default-block__header-title">MODERASİYA HAQQINDA</h3>
          </div>

          <div class="default-block__content">
            "Sandbox" da pre-moderator var: dərc olunmadan əvvəl, bütün materiallar bir UFO-nun qaranlıq şüalarından keçir.
          </div>
        </div>
    </div>
</div>

@endsection

@section('scripts')
<script>
$(document).ready(function(){
    $("#form").on("submit", function () {
        var hvalue = $('.ql-editor').html();
        $(this).append("<textarea name='body' style='display:none'>"+hvalue+"</textarea>");
    });
});

if (document.getElementById('error')) {
    iziToast.show({
        title: 'Xəta',
        icon: 'ico-error',
        message: 'Qanunsuz əməliyyat',
        progressBar: true,
        color:'red',
        close:false,
        position: 'bottomRight',
    });
}
</script>
@endsection
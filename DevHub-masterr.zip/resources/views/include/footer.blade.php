<div id="footer" class="footer">
    <div class="footer-content">
        <a class="logo-footer" href="/">DevHub</a>
        <div class="copyright">© 2019 «DevHub»</div>
        <ul class="nav-links" id="navbar-links">
            <li class="nav-links__item">
                <a href="{{ url('/') }}" class="nav-links__item-link">Paylaşmalar</a>
            </li>
            <li class="nav-links__item">
                <a href="/web/20161115054243/https://habrahabr.ru/hubs/" class="nav-links__item-link ">Hablar</a>
              </li>
            <li class="nav-links__item">
                <a href="/web/20161115054243/https://habrahabr.ru/companies/" class="nav-links__item-link ">Şirkətlər</a>
            </li>
            <li class="nav-links__item">
                <a href="/web/20161115054243/https://habrahabr.ru/users/" class="nav-links__item-link ">İnsanlar</a>
            </li>
            <li class="nav-links__item">
                <a href="/web/20161115054243/https://habrahabr.ru/sandbox/" class="nav-links__item-link ">Haqqımızda</a>
            </li>
        </ul>
        <div class="dropdown">
            <button onclick="Lang()" class="dropbtn"><i class="icon icon-globe"></i> Azərbaycan<i class="icon icon-angle-down"></i></button>
            <div id="myDropdown" class="dropdown-content">
                <a href="#"> Русский</a>
            </div>
        </div>
        <div class="social-icons">
            <li class="social-icons__item">
                <a href="#" class="fa fa-facebook"></a>
                <a href="#" class="fa fa-twitter"></a>
                <a href="#" class="fa fa-google"></a>
                <a href="#" class="fa fa-linkedin"></a>
            </li>
            
        </div>
    </div>
</div>
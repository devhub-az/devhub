<header class="layout__navbar">
	<div class="main-navbar">
		<div class="main-navbar__section main-navbar__section_left">
			<a class="logo" href="{{ route('home') }}">DevHub</a>
			<ul class="nav-links" id="navbar-links">
				<li class="nav-links__item">
					<a href="{{ url('/') }}" class="nav-links__item-link @if(Request::is('/') || Request::is('post/*') || Request::is('all') || Request::is('top/*')) nav-links__item-link_current @endif">Paylaşmalar</a>
				</li>
				<li class="nav-links__item">
				    <a href="{{ url('hubs') }}" class="nav-links__item-link @if(Request::is('hubs')) nav-links__item-link_current @endif">Hablar</a>
				  </li>
				<li class="nav-links__item">
				    <a href="#" class="nav-links__item-link ">Şirkətlər</a>
				</li>
				<li class="nav-links__item">
				    <a href="#" class="nav-links__item-link ">İnsanlar</a>
				</li>
				<li class="nav-links__item">
				    <a href="{{ url('/about_us') }}" class="nav-links__item-link @if(Request::is('about_us')) nav-links__item-link_current @endif">Haqqımızda</a>
				</li>
			</ul>
		</div>
		<form action="/search-result" class="main-navbar__section form-search" accept-charset="UTF-8" method="POST">
				{!! Form::token() !!}
				<input type="text" class="search" autocomplete="off" name="search" maxlength="48" minlength="3" placeholder="Paylasma ya hub axtar" required="required">
				{{-- <input type="text" maxlength="48" minlength="3" class="form-control" placeholder=" Поиск по каталогу" name="sku" required="required"> --}}
			</form>
		<div class="main-navbar__section main-navbar__section_right" data-style="display: flex;">
			@guest
				<a href="{{ route('login') }}" class="btn btn-primary btn_navbar_login">Daxil ol</a>
				<a href="{{ route('register') }}" class="btn btn_x-large btn_navbar_registration">Qeydiyyatdan Keç</a>
			@else
				<a href="{{ route('create_post') }}" class="btn btn-primary button_add button_width_100">Yazmağ</a>	
				{{-- <a href="{{ route('logout') }}" onclick="event.preventDefault(); document.getElementById('logout-form').submit();"></a> --}}
				<ul>
					<li class="has-dropdown">
						<img src="{{ Auth::user()->getMedia('avatars')->first()->getUrl('small') }}" alt="user avatar" class="user__avatar">
						{{-- <ul>
							<li>
								<a class="menu__item" href="/add">Добавить пост</a>
							</li>
						</ul> --}}
					</li>
				</ul>
				<form id="logout-form" action="{{ route('logout') }}" method="POST" {{-- style="display: none;" --}}>
					{{ csrf_field() }}
				</form>

				{{-- <div class="menu menu_vertical">
					<a class="menu__item" href="/add">Добавить пост</a>
					<a class="menu__item" href="/settings">Настройки</a>
					<a class="menu__item" href="/answers">Ответы </a>
					<a class="menu__item" href="/comments">Комментарии</a>
					<a class="menu__item" href="/liked">Оценки</a>
					<a class="menu__item" href="/saved-stories">Сохраненные</a>
					<a class="menu__item" href="/subs-list">Подписки</a>
					<a class="menu__item" href="/ignore-list">Игнор-лист</a>
					<a class="menu__item" href="/notes">Заметки</a>
					<span class="menu__item" data-role="logout">Выйти</span>
				</div> --}}
            @endguest
		</div>
	</div>
</header>
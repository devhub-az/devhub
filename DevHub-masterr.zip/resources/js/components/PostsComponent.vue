<template>
    <div v-if="postsNotEmpty" id="app">
        <div class="post-content"  v-for="post in posts">
            <div class="post-content__item">
                <header class="post__meta">
                    <a v-bind:href="'/@' +post.data.creator" class="post__user-info user-info" title="Автор публикации">
                    <img style="margin-left: unset;" :src="post.data.profile_image" alt="user avatar" class="user__avatar">
                    <span class="user-info__nickname user-info__nickname_small">{{ post.data.creator }}</span>
                    </a>
                    <span class="post__time">{{ post.data.created_at | timeago }} | {{ post.data.created_at |  moment('DD MMMM, H:mm') }}</span>
                    <span class="post__read-time">Oxumaq vaxtı {{ post.data.read_time }}</span>
                </header>
                <div class="post-content__header">
                    <div class="post-title">
                        <a v-bind:href="'/post/' +post.data.id">{{ post.data.title }}</a>
                    </div>
                    <div class="post-votes">
                        <i class="icon-up-outline" @click="upvote(post.data.id)" :class="{upvoted: post.upvoted}"></i>
                        <span id="raiting" style="font-family: 'Roboto',Tahoma; cursor: default;">{{ post.data.votes }}</span>
                        <i class="icon-down-outline" @click="downvote(post.data.id)" :class="{downvoted: downvoted}"></i>
                    </div>
                </div>
                <div v-if="post.data.tags" class="post__hubs">
                    <div class="tag" v-for="tag in post.data.tags">
                        {{ tag.name }}
                    </div>
                </div>
                <div class="post-content__body" v-html="post.data.body">
                </div>
                <div class="post-content__footer">
                    <div class="post-content__footer-stats">
                        <i class="icon icon-eye"></i> {{ post.data.views }}
                        <i class="icon icon-comment"></i> {{ post.data.comments.length }}
                    </div>
                    <a v-bind:href="'/post/' +post.data.id" class="btn btn-primary btn-more">Daha ətraflı...</a>
                </div>
            </div>
        </div>
        <pagination v-if="pagination.last_page > 1" :pagination="pagination" :offset="5" @paginate="getPosts()"></pagination>
    </div>
    <div v-else>
        <div class="post-content__item">
            <h4>Paylaşma tapılmadı</h4>
        </div>
    </div>
</template>

<!-- TODO: Исправить рейтинг постов -->

<script>
    export default {
        props: ['surveyData'],
        data: function() {
            return {
                posts: [],
                id: [],
                postsNotEmpty: false,
                upvoted: false,
                downvoted: false,
                pagination: {
                    'current_page': 1
                }
            }
        },
        mounted: function() {
            this.getPosts();
        },
        methods: {
            getPosts: function(){
                axios.get(this.surveyData+ '?page=' + this.pagination.current_page).then(response => {
                    if (response.data.data.length !== 0) {
                        this.posts = response.data.data;
                        this.pagination = response.data.meta;
                        if (this.pagination.last_page > 50) {
                            this.pagination.last_page = 50;
                        }
                        this.postsNotEmpty = true;
                        for (var i = 0; i < this.posts.length; i++) {
                            this.id[i] = this.posts[i].id;
                        }
                    }
                });
            },
            findVillainIdx: function(id){
                var currindex= null;
                for(var i=0; i<this.$data.posts.length; i++){
                  if (id == this.$data.posts[i].data.id)
                      {currindex = i;
                       break;}
                };
                return currindex;
            },
            upvote: function(id) {
                var index = this.findVillainIdx(id);
                const upvoted = this.posts.upvoted || false;
                this.$set(this.posts, 'upvoted', !upvoted);
                console.log(this.posts.upvoted);
                var vote = this.posts[index].data.votes;
                if (this.posts.upvoted && this.downvoted == false) {
                    vote++;
                } else if (this.posts.upvoted == false && this.downvoted == false ) {
                    vote--;
                } else if(this.posts.upvoted && this.downvoted){
                    vote=vote+2;
                }
                this.posts.downvoted = false;
                axios.post('/upvote', {
                    id: id,
                    vote: vote,
                    });
                this.posts[index].data.votes = vote;
            },
            downvote: function(id) {
                var index = this.findVillainIdx(id);
                const downvoted = this.posts.downvoted || false;
                this.$set(this.posts, 'downvoted', !downvoted);
                var vote = this.posts[index].data.votes;
                if (this.posts.downvoted && this.posts.upvoted == false) {
                    vote--;
                } else if (this.posts.upvoted == false && this.posts.downvoted == false ) {
                    vote++;
                } else if (this.posts.downvoted && this.posts.upvoted){
                    vote=vote-2;
                }
                this.upvoted = false;
                axios.post('/upvote', {
                    id: id,
                    vote: vote,
                    });
                this.posts[index].data.votes = vote;
            }
        },
    }
</script>

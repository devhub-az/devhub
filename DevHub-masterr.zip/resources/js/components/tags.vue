<template>
    <div>
    	<label class="typo__label">Tagging</label>
    	<multiselect v-model="value" placeholder="Search tag" label="name" track-by="id" :options="options" :multiple="true" :taggable="true"></multiselect>
    	<input type="hidden" id="tags" name="tags" v-bind:value="JSON.stringify(value)">
    </div>
</template>

<script>
	import Multiselect from 'vue-multiselect'

	export default {
	 	components: {
	    	Multiselect
	 	},
	  	data () {
		    return {
		    	value: null,
		    	options: []
		    }
		},
		created() {
		    this.getTags();
		},
		methods: {
		    getTags() {
		        axios.get('/api/hubs').then(response => {
		        	this.options = response.data.data;
		        });
		    },
		}

	}
</script>
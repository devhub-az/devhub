<template>
    <div class="post-content">
        <ul class="content-list">
            <li v-for="hub in hubs">
                <div class="list-hubs__hub">
                    <img class="list-hubs__hub-image" :src="'/' + hub.logo" alt="">
                    <div class="list-hubs__obj-body">
                        <div class="list-hubs__title-link">{{ hub.name }}</div>
                        <div class="list-hubs__desc">{{ hub.description }}</div>
                        <div class="list-hubs__desc">Postlar: {{ hub.posts_count }}, Followers: 2</div>
                    </div>
                    <div class="list-hubs__stats-value">
                        {{ hub.raiting }}
                    </div>
                </div>
            </li>
        </ul>
        <pagination v-if="pagination.last_page > 1" :pagination="pagination" :offset="5" @paginate="getHubs()"></pagination>
    </div>
</template>

<script>
    export default {
        data: function() {
            return {
                hubs: [],
                pagination: {
                    'current_page': 1
                }
            }
        },
        mounted: function() {
            this.getHubs();
        },
        methods: {
            getHubs: function(){
                axios.get('api/hubs?page=' + this.pagination.current_page).then(response => {
                    this.hubs = response.data.data;
                    this.pagination = response.data.meta;
                    if (this.pagination.last_page > 50) {
                        this.pagination.last_page = 50;
                    }
                });
            }
        },
    }
</script>

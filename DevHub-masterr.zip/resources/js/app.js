
/**
 * First we will load all of this project's JavaScript dependencies which
 * includes Vue and other libraries. It is a great starting point when
 * building robust, powerful web applications using Vue and Laravel.
 */

require('./bootstrap');

window.Vue = require('vue');
window.moment = require('moment');
require('moment/locale/az');
window.moment.locale('az');

axios.defaults.headers.common = {
    'X-Requested-With': 'XMLHttpRequest',
    'X-CSRF-TOKEN': document.querySelector('meta[name="csrf-token"]').getAttribute('content')
};

// Quill editor

import Quill from 'quill';
import AutoLinks from 'quill-auto-links';
// import { ImageResize } from 'quill-image-resize-module';
// import { VideoResize } from 'quill-video-resize-module';

// Quill.register('modules/imageResize', ImageResize);
// Quill.register('modules/VideoResize', VideoResize);
Quill.register('modules/autoLinks', AutoLinks);

if (document.getElementById('editor-container')) {
    var quill = new Quill('#editor-container', {
        modules: {
            syntax: true,
            autoLinks: true,
            // ImageResize: true,
            history: {
                delay: 2000,
                maxStack: 500,
                userOnly: true
            },
            // videoResize: {
            //     displaySize: true,
            //     modules: [ 'Resize', 'DisplaySize', 'Toolbar' ]
            // },
            toolbar: [
              [{ header: [1, 2, false] }],
              ['bold', 'italic', 'underline'],
              [{ 'color': [] }],
              [{ 'align': [] }],
              ['image', 'video', 'code-block'],
              ['clean']
            ],
        },
        theme: 'snow',  // or 'bubble'
    });
}

// End of Quill

/**
 * The following block of code may be used to automatically register your
 * Vue components. It will recursively scan this directory for the Vue
 * components and automatically register them with their "basename".
 *
 * Eg. ./components/ExampleComponent.vue -> <example-component></example-component>
 */

// const files = require.context('./', true, /\.vue$/i);
// files.keys().map(key => Vue.component(key.split('/').pop().split('.')[0], files(key).default));

Vue.component('posts', require('./components/PostsComponent.vue').default);
Vue.component('pagination', require('./components/pagination.vue').default);
Vue.component('tags', require('./components/tags.vue').default);
Vue.component('hubs-list', require('./components/HubsComponent.vue').default);

Vue.config.devtools=false;
Vue.config.productionTip = false;
Vue.config.silent = false;


/**
 * Next, we will create a fresh Vue application instance and attach it to
 * the page. Then, you may begin adding components to this application
 * or customize the JavaScript scaffolding to fit your unique needs.
 */

Vue.filter('moment', function(value, format) {
    return moment(value).format(format);
});
Vue.filter('timeago', function(value) {
    return moment(value).fromNow();
});

if (document.getElementById('app')){
    const app = new Vue({
        el: '#app'
    });
}
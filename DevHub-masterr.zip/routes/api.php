<?php

use Illuminate\Http\Request;

/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
|
| Here is where you can register API routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| is assigned the "api" middleware group. Enjoy building your API!
|
*/

Route::middleware('auth:api')->get('/user', function (Request $request) {
    return $request->user();
});


Route::get('posts/top/day', 'PostController@indexDay');
Route::get('posts/top/week', 'PostController@indexWeek')->name('top.week');
Route::get('posts/top/month', 'PostController@indexMonth')->name('top.month');
Route::get('posts/all', 'PostController@indexAll')->name('all');


Route::get('hubs', 'HubsController@hubs');
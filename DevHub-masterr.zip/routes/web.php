<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', 'HomeController@index')->name('home');
Route::get('/top/week', 'HomeController@indexWeek')->name('top.week');
Route::get('/top/month', 'HomeController@indexMonth')->name('top.month');
Route::get('/all', 'HomeController@all')->name('all');

Route::prefix('post')->group(function () {
    Route::get('/add', 'PostController@create')->name('create_post');
    Route::get('/{id}', 'PostController@show')->name('show');
    Route::post('/{post}', 'PostController@updateViews');
});

Route::get('search-result', 'SearchController@index')->name('search-result');
Route::post('search-result', 'SearchController@index');

Route::get('users', 'UserController@userList')->name('user-list');

Route::prefix('comment')->group(function(){
	Route::post('new-comment', 'CommentController@newComment')->name('new-comment');
});

Route::get('/@{username}', 'UserController@show')->name('user_profile');

Route::post('profile/{profileId}/follow', 'ProfileController@followUser')->name('user.follow');
Route::post('/{profileId}/unfollow', 'ProfileController@unFollowUser')->name('user.unfollow');

Auth::routes();

Route::resource('posts', 'PostController');

Route::get('hubs', 'HubsController@index');

Route::get('about_us', function(){
	return view('pages.about_us');
});

// FUTURE
Route::post('upvote', 'PostController@updateVote');

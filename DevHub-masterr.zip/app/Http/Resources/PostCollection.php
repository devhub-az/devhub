<?php

namespace App\Http\Resources;

use Illuminate\Http\Resources\Json\JsonResource;

class PostCollection extends JsonResource
{
    /**
     * Transform the resource into an array.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return array
     */
    public function toArray($request)
    {
        return [
            'data' => [
                'id' => $this->id,
                'title' => $this->name,
                'body' => $this->shorten($this->body, 1000),
                'creator' => $this->creator->username,
                'profile_image' => $this->creator->getMedia('avatars')->first()->getUrl('small'),
                'votes' => $this->votes,
                'tags' => $this->tags,
                'comments' => $this->comments,
                'views' => $this->views,
                'created_at' => $this->created_at,
                'read_time' => $this->readTime($this->body),
            ],
        ];
    }

    public function shorten(string $text, int $maxLength) {
        $shortText = substr($text, 0, $maxLength);

        // dd((strrpos($shortText, ".") ? substr($shortText, 0, strrpos($shortText, ".")) : $shortText) . (strlen($text) > $maxLength ? "..." : ""));

        return ((strrpos($shortText, ".") ? substr($shortText, 0, strrpos($shortText, ".")) : $shortText) . (strlen($text) > $maxLength ? '...' : ''));
    }

    public function readTime($text){
        $word = str_word_count(strip_tags($text));
        $m = floor($word / 200);
        $est = $m . ' dəqiqə';
        return $est;
    }
}

<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Http\Resources\HubsCollection;
use App\Models\Hubs;

class HubsController extends Controller
{
    public function index()
    {
    	return view('pages.hubs');
    }

    public function hubs()
    {
    	return new HubsCollection(Hubs::paginate(10));
    }
}

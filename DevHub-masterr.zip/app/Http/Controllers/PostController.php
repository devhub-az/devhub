<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use App\Models\Post;
use App\Models\PostsVotes;
use App\Http\Resources\PostsCollection;
use DB;

class PostController extends Controller
{

	public function __construct() {
        $this->middleware('auth', ['only' => ['create', 'store', 'edit', 'updateVote'] ]);
    }

    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function indexDay()
    {
        return new PostsCollection(Post::where(DB::raw('DATE(created_at)'), '=', DB::raw('DATE_SUB(CURDATE(), INTERVAL 0 DAY)'))->orderBy('votes', 'DESC')->orderBy('created_at', 'DESC')
            ->with('creator:id,username')
            ->with('tags:name')
            ->with('comments')
            ->paginate(5));
    }

    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function indexWeek()
    {
        return new PostsCollection(Post::where(DB::raw('DATE(created_at)'), '>', DB::raw('DATE_SUB(CURDATE(), INTERVAL 7 DAY)'))->orderBy('votes', 'DESC')->orderBy('created_at', 'DESC')
            ->with('creator:id,username')
            ->with('tags:name')
            ->with('comments:body')
            ->paginate(5));
    }

    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function indexMonth()
    {
        return new PostsCollection(Post::where(DB::raw('DATE(created_at)'), '>', DB::raw('DATE_SUB(CURDATE(), INTERVAL 30 DAY)'))->orderBy('votes', 'DESC')->orderBy('created_at', 'DESC')
            ->with('creator:id,username')
            ->with('tags:name')
            ->with('comments:body')
            ->paginate(5));
    }
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function indexAll()
    {
        return new PostsCollection(Post::orderBy('created_at', 'DESC')
            ->with('creator:id,username')
            ->with('tags:name')
            ->with('comments:body')
            ->paginate(5));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        return view('pages.posts.create');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $request->validate([
           'title' => 'required|string',
           'body' => 'required|string|min:110',
           // 'tags' => 'required',
        ]);

        $share = new Post([
          'name' => $request->get('title'),
          'body'=> $request->get('body'),
          'author_id'=> Auth::user()->id, 
        ]);

        $share->save();
        return redirect('/')->with('success', 'Stock has been added');
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show(Request $request, $id)
    {
        $post = Post::findOrFail($id);
        return view('pages.posts.show', [
            'post' => $post,
            'comments' => $post->comments()->with('author')->get()
        ]);
    }

    public function updateVote(Request $request)
    {
        $request->validate([
            'id' => 'required|int',
            'vote' => 'required|int',
        ]);

        $share = Posts::findOrFail($request->get('id'));
        $share->votes = $request->get('vote');
        $share->save();
        
        $vote = new PostsVotes([
            'user_id' => Auth::user()->id,
            'post_id' => $request->get('id'),
        ]);
        $vote->save();
    }

    public function updateViews(Post $post)
    {
        $post->increment('views');
        return response()->json([]);
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }
}

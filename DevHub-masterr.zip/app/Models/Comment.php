<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Comment extends Model
{
    /**
     * The database table used by the model.
     *
     * @var string
     */
    protected $table = 'comments';

    protected $fillable = [
        'comment'
    ];

    // public function posts() {
    //     return $this->belongsTo('App\Post', 'post_id');
    // }
    
    public function author()
    {
        return $this->belongsTo(User::class,'author_id');
    }

    public function post()
    {
        return $this->belongsTo(Posts::class,'post_id')->withDefault();
    }
}

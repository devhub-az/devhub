<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Hubs extends Model
{
	protected $table = 'hubs';

	protected $fillable = [
		'name'
	];

	public function posts(){
        return $this->belongsToMany(Post::class, 'post_hubs', 'hub_id', 'posts_id');
    }
}
